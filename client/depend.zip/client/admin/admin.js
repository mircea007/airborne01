var popup = document.getElementById('popups');

function send(){
  
  popup.style.display = "none";
  popup.innerHTML = "";
}

function getPass(){
  popup.innerHTML = 'Please enter admin request password <br> <input id = "pass" type = "password"> <br> <button onclick = "clicked = true">send request</button>';
  popup.style.display = "block";
}

function req_admin_status(){
  var pass = myhash(getPass());

  console.log('sending admin password request..');
  socket.emit('admin_req', {p: pass});
}
